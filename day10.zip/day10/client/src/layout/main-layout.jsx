import React from 'react'
import { Link, Outlet } from 'react-router-dom'

export const MainLayout = () => {
  return (
    <>
    <div className='p-[40px] bg-blue-300'></div>
    <div className='flex'>
       <ul className='h-screen bg-blue-300 p-5 w-[300px] '>
        <li className='p-5 py-2 rounded-lg hover:bg-blue-400 mb-2 bg-white'>
          <Link className='text-xl font-medium hover:text-blue-700 ' to="/app">Home</Link>
        </li>
        <li className='p-5 py-2 rounded-lg hover:bg-blue-400 mb-2 bg-white'>
          <Link className='text-xl font-medium hover:text-blue-700 ' to="/app/category">Category</Link>
        </li>
        <li className='p-5 py-2 rounded-lg hover:bg-blue-400 mb-2 bg-white'>
          <Link className='text-xl font-medium hover:text-blue-700 ' to="/app/product">Product</Link>
        </li>
        <li className='p-5 py-2 rounded-lg hover:bg-blue-400 mb-2 bg-white'>
          <Link className='text-xl font-medium hover:text-blue-700 ' to="/app/banner">Banner</Link>
        </li>
       </ul>
       <div className='flex-grow p-5'>
        <Outlet/>
       </div>
    </div>
    </>
  )
}
