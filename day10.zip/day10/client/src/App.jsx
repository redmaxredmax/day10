import { Route, Routes } from "react-router-dom"
import { MainLayout } from "./layout/main-layout"
import router from "./router/router"
import { Login } from "./pages/login/login"
import { Category } from "./pages/category/category"
import { Home } from "./pages/home/home"
import { Product } from "./pages/product/product"
import {Banner} from "./pages/banner"
import { CategoryCreate } from "./pages/category/category-create"

function App() {

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/app" element={<MainLayout />} >
        <Route index element={<Home/>}/>
        <Route path="category" element={<Category/>}/>
        <Route path="product" element={<Product/>}/>
        <Route path="banner" element={<Banner/>}/>
        <Route path="category/create" element={<CategoryCreate/>}/>
      </Route>
    </Routes>
  )
}

export default App
