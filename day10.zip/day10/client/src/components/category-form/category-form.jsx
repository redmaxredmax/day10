import React from 'react'

import { useForm } from 'react-hook-form'
import { Button } from '../ui/button'
import { Input } from '../ui/input'


export const CategoryForm = ({ submit }) => {
    const { handleSubmit, register, reset } = useForm()

    return (

        <form onSubmit={handleSubmit(submit)} className='w-[500px]'>
            <div>
                <Input {...register("title", { required: true })} placeholder="Enter Title" type="text" />
            </div>
            <div>
                <Input {...register("img", { required: true })} placeholder="Enter Image Url" type="text" />
            </div>
            <Button type="submit" variant="category">Confirm</Button>
        </form>

    )
}
