import React from 'react'
import clsx from 'clsx'


export const Button = ({ type, variant, children, onClick, icon1: startIcon, icon2:endIcon }) => {
  return (
    <button
            type={type}
            onClick={onClick}
            className={clsx(" py-2 px-2 w-[300px] outline-none mb-3 rounded-xl", {
                "bg-blue-400 text-xl font-bold hover:bg-blue-600": variant == "primary",
                "ml-[100px] px-4 bg-blue-400":variant==="category"
            })}
        >
            {startIcon ? startIcon : ""}
            <span>{children}</span>
            {endIcon ? endIcon : ""}
        </button>
  )
}
