import React from 'react'
import clsx from 'clsx'


export const Input = React.forwardRef(
    ({ name, type, id, onChange, placeholder, value, label, error, helperText,className,variant,required,defaultValue, ...resTprop  }, ref) => {
        return (
            <div className='mb-3 flex flex-col w-[300px] mx-auto'>
                {label && <label className='text-start text-base font-medium ml-3 mb-1' htmlFor={id}>{label}</label>}
                <input {...resTprop} className={clsx("bg-gray-200 py-3 rounded-xl px-4 w-[300px] outline-none ",{
                    "":variant==="primary",
                    "":variant===""
                },className,error&&"border-2 border-red-400")} ref={ref} placeholder={placeholder} defaultValue={defaultValue} id={id} name={name} onChange={onChange} required={required} value={value} type={type} />
               {helperText && <p className='text-red-400 font-medium text-sm'>{helperText}</p>}
            </div>
        )
    }

)