import { nanoid } from "@reduxjs/toolkit";
import { Home } from "../pages/home/home";
import { Login } from "../pages/login/login";

export default [
    {
        component: <Home />,
        id: nanoid(),
    },
    {
        component: <Login />,
        id: nanoid(),
        path: "category/:slug"
    },
]