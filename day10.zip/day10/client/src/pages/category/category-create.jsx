import React from 'react'
import { useCreateCategory } from './service/mutation/useCreateCategory'
import { CategoryForm } from '../../components/category-form/category-form'
import { useNavigate } from 'react-router-dom'

export const CategoryCreate = () => {
  const {mutate,isPending}=useCreateCategory()
  const navigate=useNavigate()
  const submit=(data)=>{
    mutate(data,{
      onSuccess:()=>{
        navigate('/app/category')
      }
    })
  }

  return (
    <CategoryForm submit={submit}/>
  )
}
