import React from 'react'
import { Button } from '../../components/ui/button'
import { Link } from 'react-router-dom'

export const Category = () => {
  return (
    <div>
        <Link to="/app/category/create">Create</Link>
        <ul>
            <li>item</li>
            <li>item</li>
            <li>item</li>
            <li>item</li>
            <li>item</li>
        </ul>
    </div>
  )
}
